// 4. Menú hamburguesa para móviles
const hamburger = document.querySelector('.hamburger');
const navLinks = document.querySelector('.nav-links');

hamburger.addEventListener('click', () => {
    navLinks.classList.toggle('active');
});

// 5. Validación del formulario
const contactForm = document.getElementById('contactForm');

contactForm.addEventListener('submit', function(e) {
    e.preventDefault();
    let isValid = true;
    
    // Validar nombre
    const nombre = document.getElementById('nombre');
    const nombreError = document.getElementById('nombreError');
    if (nombre.value.trim() === '') {
        nombreError.style.display = 'block';
        isValid = false;
    } else {
        nombreError.style.display = 'none';
    }
    
    // Validar email
    const email = document.getElementById('email');
    const emailError = document.getElementById('emailError');
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email.value)) {
        emailError.style.display = 'block';
        isValid = false;
    } else {
        emailError.style.display = 'none';
    }
    
    // Validar fruta
    const fruta = document.getElementById('fruta');
    const frutaError = document.getElementById('frutaError');
    if (fruta.value === '') {
        frutaError.style.display = 'block';
        isValid = false;
    } else {
        frutaError.style.display = 'none';
    }
    
    // Validar cantidad
    const cantidad = document.getElementById('cantidad');
    const cantidadError = document.getElementById('cantidadError');
    if (cantidad.value === '' || cantidad.value < 1) {
        cantidadError.style.display = 'block';
        isValid = false;
    } else {
        cantidadError.style.display = 'none';
    }
    
    // Si todo es válido, se puede enviar el formulario
    if (isValid) {
        alert('Gracias por tu mensaje. Nos pondremos en contacto contigo pronto.');
        contactForm.reset();
    }
});